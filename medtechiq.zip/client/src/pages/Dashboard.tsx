import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  BookOpen,
  Zap,
  BarChart3,
  Trophy,
  Brain,
  Sparkles,
  MessageCircle,
  Bell,
  Settings,
  LogOut,
  ArrowRight,
} from "lucide-react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const features = [
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Quiz Engine",
      description: "Take adaptive quizzes with instant feedback",
      path: "/quiz",
      color: "from-primary to-primary/50",
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Flashcards",
      description: "Master concepts with 3D flip animations",
      path: "/flashcards",
      color: "from-accent to-accent/50",
    },
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: "Analytics",
      description: "Track your performance and progress",
      path: "/analytics",
      color: "from-secondary to-secondary/50",
    },
    {
      icon: <Trophy className="w-8 h-8" />,
      title: "Gamification",
      description: "Earn points, badges, and climb leaderboards",
      path: "/gamification",
      color: "from-accent to-accent/50",
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "Mistake Notebook",
      description: "Review and learn from your mistakes",
      path: "/mistakes",
      color: "from-primary to-primary/50",
    },
    {
      icon: <MessageCircle className="w-8 h-8" />,
      title: "AI Chatbot",
      description: "Get instant help with your doubts",
      path: "/chatbot",
      color: "from-secondary to-secondary/50",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/5">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">MEDTECHIQ</h1>
          </div>

          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-foreground"
            >
              <Bell className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-foreground"
            >
              <Settings className="w-5 h-5" />
            </Button>
            <Button
              onClick={() => logout()}
              variant="outline"
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 space-y-2"
        >
          <h2 className="text-4xl font-bold text-foreground">
            Welcome back, {user?.name}! 👋
          </h2>
          <p className="text-lg text-muted-foreground">
            Continue your journey to ace NEET & JEE exams
          </p>
        </motion.div>

        {/* Quick Stats */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-4 gap-4 mb-12"
        >
          {[
            { label: "Streak", value: "12 days", icon: "🔥" },
            { label: "Points", value: "2,450", icon: "⭐" },
            { label: "Level", value: "8", icon: "🎯" },
            { label: "Accuracy", value: "87%", icon: "✅" },
          ].map((stat, i) => (
            <motion.div key={i} variants={itemVariants}>
              <Card className="p-4 space-y-2">
                <p className="text-2xl">{stat.icon}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Features Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {features.map((feature, i) => (
            <motion.div key={i} variants={itemVariants}>
              <Card
                onClick={() => navigate(feature.path)}
                className="p-6 cursor-pointer hover:shadow-lg hover:border-primary/50 transition-all group h-full"
              >
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} p-2.5 mb-4 text-primary-foreground group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {feature.description}
                </p>
                <div className="flex items-center text-primary group-hover:translate-x-1 transition-transform">
                  <span className="text-sm font-medium">Get Started</span>
                  <ArrowRight className="w-4 h-4 ml-2" />
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-12"
        >
          <Card className="p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">
              Recent Activity
            </h3>
            <div className="space-y-4">
              {[
                {
                  title: "Completed Physics Quiz",
                  score: "92%",
                  time: "2 hours ago",
                },
                {
                  title: "Reviewed 15 Flashcards",
                  score: "Chemistry",
                  time: "5 hours ago",
                },
                {
                  title: "Achieved 'Streak Master' Badge",
                  score: "7 days",
                  time: "1 day ago",
                },
              ].map((activity, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                >
                  <div>
                    <p className="font-medium text-foreground">{activity.title}</p>
                    <p className="text-sm text-muted-foreground">{activity.time}</p>
                  </div>
                  <p className="text-sm font-semibold text-primary">{activity.score}</p>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
