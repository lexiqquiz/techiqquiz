import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, RotateCcw, Plus, Trash2 } from "lucide-react";

interface Flashcard {
  id: number;
  front: string;
  back: string;
  subject: string;
  difficulty: string;
  reviewCount: number;
}

export default function Flashcards() {
  const [flashcards, setFlashcards] = useState<Flashcard[]>([
    {
      id: 1,
      front: "What is the formula for kinetic energy?",
      back: "KE = ½mv² where m is mass and v is velocity",
      subject: "Physics",
      difficulty: "easy",
      reviewCount: 5,
    },
    {
      id: 2,
      front: "Define osmosis",
      back: "Movement of solvent molecules across a semipermeable membrane from lower to higher solute concentration",
      subject: "Biology",
      difficulty: "medium",
      reviewCount: 3,
    },
    {
      id: 3,
      front: "What is the pH formula?",
      back: "pH = -log[H⁺] where [H⁺] is hydrogen ion concentration",
      subject: "Chemistry",
      difficulty: "medium",
      reviewCount: 7,
    },
  ]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [showNewForm, setShowNewForm] = useState(false);
  const [newCard, setNewCard] = useState({ front: "", back: "", subject: "Physics" });

  const filteredCards = selectedSubject
    ? flashcards.filter((card) => card.subject === selectedSubject)
    : flashcards;

  const currentCard = filteredCards[currentIndex];

  const handleNext = () => {
    if (currentIndex < filteredCards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setIsFlipped(false);
    }
  };

  const handleReset = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
  };

  const handleAddCard = () => {
    if (newCard.front.trim() && newCard.back.trim()) {
      const card: Flashcard = {
        id: Math.max(...flashcards.map((c) => c.id), 0) + 1,
        front: newCard.front,
        back: newCard.back,
        subject: newCard.subject,
        difficulty: "medium",
        reviewCount: 0,
      };
      setFlashcards([...flashcards, card]);
      setNewCard({ front: "", back: "", subject: "Physics" });
      setShowNewForm(false);
    }
  };

  const handleDeleteCard = (id: number) => {
    const newCards = flashcards.filter((card) => card.id !== id);
    setFlashcards(newCards);
    if (currentIndex >= newCards.length) {
      setCurrentIndex(Math.max(0, newCards.length - 1));
    }
  };

  const subjects = Array.from(new Set(flashcards.map((card) => card.subject)));

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/5 py-12">
      <div className="container">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">Flashcards</h1>
          <p className="text-muted-foreground">Master concepts with interactive flashcards</p>
        </div>

        {/* Subject Filter */}
        <div className="mb-8 flex flex-wrap gap-2">
          <Button
            onClick={() => setSelectedSubject(null)}
            variant={selectedSubject === null ? "default" : "outline"}
            className={selectedSubject === null ? "bg-primary text-primary-foreground" : ""}
          >
            All Subjects
          </Button>
          {subjects.map((subject) => (
            <Button
              key={subject}
              onClick={() => setSelectedSubject(subject)}
              variant={selectedSubject === subject ? "default" : "outline"}
              className={selectedSubject === subject ? "bg-primary text-primary-foreground" : ""}
            >
              {subject}
            </Button>
          ))}
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Flashcard Display */}
          <div className="lg:col-span-2 space-y-8">
            {filteredCards.length > 0 ? (
              <>
                {/* 3D Flip Card */}
                <div className="h-96 perspective">
                  <motion.div
                    initial={false}
                    animate={{ rotateY: isFlipped ? 180 : 0 }}
                    transition={{ duration: 0.6 }}
                    style={{ transformStyle: "preserve-3d" }}
                    onClick={() => setIsFlipped(!isFlipped)}
                    className="w-full h-full cursor-pointer"
                  >
                    {/* Front */}
                    <motion.div
                      style={{
                        backfaceVisibility: "hidden",
                        WebkitBackfaceVisibility: "hidden",
                      }}
                      className="absolute w-full h-full"
                    >
                      <Card className="w-full h-full p-8 flex flex-col items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 hover:border-primary/50 transition-all">
                        <p className="text-center text-2xl font-semibold text-foreground mb-4">
                          {currentCard?.front}
                        </p>
                        <p className="text-center text-muted-foreground text-sm">Click to reveal answer</p>
                      </Card>
                    </motion.div>

                    {/* Back */}
                    <motion.div
                      initial={{ rotateY: 180 }}
                      animate={{ rotateY: isFlipped ? 0 : 180 }}
                      transition={{ duration: 0.6 }}
                      style={{
                        backfaceVisibility: "hidden",
                        WebkitBackfaceVisibility: "hidden",
                      }}
                      className="absolute w-full h-full"
                    >
                      <Card className="w-full h-full p-8 flex flex-col items-center justify-center bg-gradient-to-br from-accent/10 to-secondary/10 border-2 border-accent/20 hover:border-accent/50 transition-all">
                        <p className="text-center text-xl text-foreground">
                          {currentCard?.back}
                        </p>
                      </Card>
                    </motion.div>
                  </motion.div>
                </div>

                {/* Card Info */}
                <Card className="p-6 space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Subject</p>
                      <p className="font-semibold text-foreground">{currentCard?.subject}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Difficulty</p>
                      <p className="font-semibold text-foreground capitalize">{currentCard?.difficulty}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Reviews</p>
                      <p className="font-semibold text-foreground">{currentCard?.reviewCount}</p>
                    </div>
                  </div>
                </Card>

                {/* Navigation */}
                <div className="flex gap-4">
                  <Button
                    onClick={handlePrevious}
                    disabled={currentIndex === 0}
                    variant="outline"
                    className="flex-1"
                  >
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Previous
                  </Button>
                  <Button
                    onClick={handleReset}
                    variant="outline"
                    className="flex-1"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Reset
                  </Button>
                  <Button
                    onClick={handleNext}
                    disabled={currentIndex === filteredCards.length - 1}
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Next
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>

                {/* Progress */}
                <div className="text-center">
                  <p className="text-muted-foreground">
                    Card {currentIndex + 1} of {filteredCards.length}
                  </p>
                  <div className="mt-2 h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all duration-300"
                      style={{ width: `${((currentIndex + 1) / filteredCards.length) * 100}%` }}
                    />
                  </div>
                </div>
              </>
            ) : (
              <Card className="p-12 text-center space-y-4">
                <p className="text-muted-foreground">No flashcards found</p>
                <Button
                  onClick={() => setShowNewForm(true)}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Card
                </Button>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Create New Card */}
            <Card className="p-4 space-y-4">
              <h3 className="font-semibold text-foreground">Create Card</h3>
              {showNewForm ? (
                <div className="space-y-3">
                  <input
                    type="text"
                    placeholder="Front (Question)"
                    value={newCard.front}
                    onChange={(e) => setNewCard({ ...newCard, front: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  <textarea
                    placeholder="Back (Answer)"
                    value={newCard.back}
                    onChange={(e) => setNewCard({ ...newCard, back: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                    rows={3}
                  />
                  <select
                    value={newCard.subject}
                    onChange={(e) => setNewCard({ ...newCard, subject: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option>Physics</option>
                    <option>Chemistry</option>
                    <option>Biology</option>
                    <option>Mathematics</option>
                  </select>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleAddCard}
                      className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                    >
                      Add
                    </Button>
                    <Button
                      onClick={() => setShowNewForm(false)}
                      variant="outline"
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  onClick={() => setShowNewForm(true)}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Card
                </Button>
              )}
            </Card>

            {/* Card List */}
            <Card className="p-4 space-y-2 max-h-96 overflow-y-auto">
              <h3 className="font-semibold text-foreground mb-3">Your Cards</h3>
              {filteredCards.map((card, idx) => (
                <motion.div
                  key={card.id}
                  whileHover={{ x: 4 }}
                  onClick={() => {
                    setCurrentIndex(idx);
                    setIsFlipped(false);
                  }}
                  className={`p-3 rounded-lg cursor-pointer transition-all ${
                    idx === currentIndex
                      ? "bg-primary/20 border border-primary"
                      : "bg-secondary/50 hover:bg-secondary border border-border"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{card.front}</p>
                      <p className="text-xs text-muted-foreground">{card.subject}</p>
                    </div>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteCard(card.id);
                      }}
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive/90"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
