import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { motion } from "framer-motion";
import { ArrowRight, Zap, Brain, BarChart3, Trophy, BookOpen, Sparkles, Users, Target } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  };

  const features = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Smart Quiz Engine",
      description: "Adaptive quizzes with real-time feedback, timer, and marking scheme support",
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: "Interactive Flashcards",
      description: "3D flip animations for active recall learning and spaced repetition",
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: "Advanced Analytics",
      description: "Subject-wise breakdown, weak areas identification, and performance trends",
    },
    {
      icon: <Trophy className="w-6 h-6" />,
      title: "Gamification",
      description: "Earn points, badges, streaks, and compete on leaderboards",
    },
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "Mistake Notebook",
      description: "Review incorrect answers with explanations and retry functionality",
    },
    {
      icon: <Sparkles className="w-6 h-6" />,
      title: "AI Chatbot",
      description: "Get instant help with concepts, doubt resolution, and personalized tips",
    },
  ];

  const stats = [
    { label: "Questions", value: "50,000+" },
    { label: "Active Students", value: "100,000+" },
    { label: "Success Rate", value: "92%" },
    { label: "Avg Score Improvement", value: "+35%" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-secondary/5">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Target className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="font-bold text-xl text-foreground">MEDTECHIQ</span>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted-foreground">Welcome, {user?.name}</span>
                <Button
                  onClick={() => navigate("/dashboard")}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Dashboard
                </Button>
              </>
            ) : (
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Sign In with Google            </Button>
              )
            }
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 gap-12 items-center"
        >
          <motion.div variants={itemVariants} className="space-y-6">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Master Your <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Exams</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                The most comprehensive NEET & JEE preparation platform with AI-powered learning, gamification, and personalized analytics.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground group"
              >
                Get Started Free
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-border hover:bg-secondary/50"
              >
                Watch Demo
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4">
              {stats.map((stat, i) => (
                <motion.div
                  key={i}
                  variants={itemVariants}
                  className="space-y-1"
                >
                  <p className="text-2xl font-bold text-primary">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="relative h-96 md:h-full"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl blur-3xl" />
            <div className="relative bg-gradient-to-br from-card to-card/50 rounded-3xl border border-border p-8 shadow-2xl">
              <div className="space-y-4">
                <div className="h-12 bg-primary/10 rounded-lg animate-pulse" />
                <div className="space-y-2">
                  <div className="h-4 bg-primary/10 rounded w-3/4 animate-pulse" />
                  <div className="h-4 bg-primary/10 rounded w-1/2 animate-pulse" />
                </div>
                <div className="grid grid-cols-3 gap-3 pt-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-20 bg-accent/10 rounded-lg animate-pulse" />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 md:py-32 bg-secondary/5">
        <div className="container">
          <motion.div
            variants={itemVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Powerful Features for Success
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to ace NEET and JEE exams in one elegant platform
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-6"
          >
            {features.map((feature, i) => (
              <motion.div key={i} variants={itemVariants}>
                <Card className="h-full p-6 hover:shadow-lg hover:border-primary/50 transition-all duration-300 cursor-pointer group">
                  <div className="text-primary mb-4 group-hover:scale-110 transition-transform">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {feature.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-20 md:py-32">
        <div className="container">
          <motion.div
            variants={itemVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Trusted by Top Students
            </h2>
            <p className="text-lg text-muted-foreground">
              Join thousands of successful NEET and JEE aspirants
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-6"
          >
            {[
              {
                name: "Arjun Sharma",
                score: "720/720",
                exam: "JEE Advanced",
                quote: "MEDTECHIQ's analytics helped me identify weak areas and improve systematically.",
              },
              {
                name: "Priya Patel",
                score: "680/720",
                exam: "NEET",
                quote: "The flashcards and mistake notebook were game-changers for my preparation.",
              },
              {
                name: "Rohan Gupta",
                score: "650/720",
                exam: "JEE Main",
                quote: "The AI chatbot answered all my doubts instantly. Highly recommended!",
              },
            ].map((testimonial, i) => (
              <motion.div key={i} variants={itemVariants}>
                <Card className="p-6 bg-card/50 border-border">
                  <div className="flex items-center gap-2 mb-4">
                    {[...Array(5)].map((_, j) => (
                      <Sparkles key={j} className="w-4 h-4 text-accent fill-accent" />
                    ))}
                  </div>
                  <p className="text-foreground mb-4 italic">"{testimonial.quote}"</p>
                  <div className="border-t border-border pt-4">
                    <p className="font-semibold text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {testimonial.score} • {testimonial.exam}
                    </p>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="container">
          <motion.div
            variants={itemVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-center space-y-8"
          >
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                Ready to Transform Your Preparation?
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Start your journey to success with MEDTECHIQ today. Free to get started, premium features available.
              </p>
            </div>

            <Button
              onClick={() => (window.location.href = getLoginUrl())}
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground group mx-auto"
            >
              Start Learning Now
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold text-foreground mb-4">MEDTECHIQ</h3>
              <p className="text-sm text-muted-foreground">
                The ultimate NEET & JEE preparation platform
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition">Features</a></li>
                <li><a href="#" className="hover:text-primary transition">Pricing</a></li>
                <li><a href="#" className="hover:text-primary transition">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition">About</a></li>
                <li><a href="#" className="hover:text-primary transition">Blog</a></li>
                <li><a href="#" className="hover:text-primary transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition">Privacy</a></li>
                <li><a href="#" className="hover:text-primary transition">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 MEDTECHIQ. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
