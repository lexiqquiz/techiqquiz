import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Clock, ChevronLeft, ChevronRight, Flag, SkipForward } from "lucide-react";

interface Question {
  id: number;
  questionText: string;
  questionImageUrl?: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctOption: string;
  positiveMarks: number;
  negativeMarks: number;
  explanation: string;
}

interface QuizState {
  currentQuestion: number;
  answers: Record<number, string | null>;
  flagged: Set<number>;
  timeSpent: Record<number, number>;
  showResult: boolean;
}

export default function QuizEngine() {
  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestion: 0,
    answers: {},
    flagged: new Set(),
    timeSpent: {},
    showResult: false,
  });

  const [timeLeft, setTimeLeft] = useState(3600);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const questionTimerRef = useRef<NodeJS.Timeout | null>(null);
  const questionStartTimeRef = useRef<number>(Date.now());

  // Fetch questions
  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const mockQuestions: Question[] = [
          {
            id: 1,
            questionText: "What is the value of ∫₀¹ x² dx?",
            optionA: "1/3",
            optionB: "1/2",
            optionC: "2/3",
            optionD: "1",
            correctOption: "A",
            positiveMarks: 4,
            negativeMarks: 1,
            explanation: "Using the power rule of integration: ∫ x² dx = x³/3. Evaluating from 0 to 1 gives 1/3.",
          },
          {
            id: 2,
            questionText: "The pH of a neutral solution at 25°C is:",
            optionA: "0",
            optionB: "7",
            optionC: "14",
            optionD: "10",
            correctOption: "B",
            positiveMarks: 4,
            negativeMarks: 1,
            explanation: "At 25°C, the pH of a neutral solution is 7, where [H⁺] = [OH⁻] = 10⁻⁷ M.",
          },
          {
            id: 3,
            questionText: "Which of the following is a vector quantity?",
            optionA: "Speed",
            optionB: "Temperature",
            optionC: "Acceleration",
            optionD: "Distance",
            correctOption: "C",
            positiveMarks: 4,
            negativeMarks: 1,
            explanation: "Acceleration has both magnitude and direction, making it a vector quantity.",
          },
        ];
        setQuestions(mockQuestions);
        setLoading(false);
      } catch (error) {
        console.error("Failed to fetch questions:", error);
        setLoading(false);
      }
    };

    fetchQuestions();
  }, []);

  // Overall timer
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          if (timerRef.current) clearInterval(timerRef.current);
          handleSubmitQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Question timer
  useEffect(() => {
    questionStartTimeRef.current = Date.now();
    questionTimerRef.current = setInterval(() => {
      const timeSpent = Math.floor((Date.now() - questionStartTimeRef.current) / 1000);
      setQuizState((prev) => ({
        ...prev,
        timeSpent: {
          ...prev.timeSpent,
          [questions[prev.currentQuestion]?.id]: timeSpent,
        },
      }));
    }, 1000);

    return () => {
      if (questionTimerRef.current) clearInterval(questionTimerRef.current);
    };
  }, [quizState.currentQuestion, questions]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleSelectOption = (option: string) => {
    const questionId = questions[quizState.currentQuestion]?.id;
    setQuizState((prev) => ({
      ...prev,
      answers: {
        ...prev.answers,
        [questionId]: option,
      },
    }));
  };

  const handleSkipQuestion = () => {
    const questionId = questions[quizState.currentQuestion]?.id;
    setQuizState((prev) => ({
      ...prev,
      answers: {
        ...prev.answers,
        [questionId]: null,
      },
    }));
    handleNextQuestion();
  };

  const handleFlagQuestion = () => {
    const questionId = questions[quizState.currentQuestion]?.id;
    setQuizState((prev) => {
      const newFlagged = new Set(prev.flagged);
      if (newFlagged.has(questionId)) {
        newFlagged.delete(questionId);
      } else {
        newFlagged.add(questionId);
      }
      return {
        ...prev,
        flagged: newFlagged,
      };
    });
  };

  const handleNextQuestion = () => {
    if (quizState.currentQuestion < questions.length - 1) {
      setQuizState((prev) => ({
        ...prev,
        currentQuestion: prev.currentQuestion + 1,
      }));
    }
  };

  const handlePreviousQuestion = () => {
    if (quizState.currentQuestion > 0) {
      setQuizState((prev) => ({
        ...prev,
        currentQuestion: prev.currentQuestion - 1,
      }));
    }
  };

  const handleSubmitQuiz = () => {
    setQuizState((prev) => ({
      ...prev,
      showResult: true,
    }));
  };

  const calculateScore = () => {
    let score = 0;
    questions.forEach((question) => {
      const userAnswer = quizState.answers[question.id];
      if (userAnswer === question.correctOption) {
        score += question.positiveMarks;
      } else if (userAnswer !== null && userAnswer !== undefined) {
        score -= question.negativeMarks;
      }
    });
    return score;
  };

  const calculateAccuracy = () => {
    let correct = 0;
    questions.forEach((question) => {
      if (quizState.answers[question.id] === question.correctOption) {
        correct += 1;
      }
    });
    return Math.round((correct / questions.length) * 100);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-muted-foreground">Loading quiz...</p>
        </div>
      </div>
    );
  }

  if (quizState.showResult) {
    const score = calculateScore();
    const accuracy = calculateAccuracy();

    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary/5 py-12">
        <div className="container max-w-2xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-8"
          >
            <Card className="p-8 text-center space-y-6">
              <div className="space-y-2">
                <h1 className="text-4xl font-bold text-foreground">Quiz Completed!</h1>
                <p className="text-muted-foreground">Here's your performance summary</p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="bg-primary/10 rounded-lg p-4">
                  <p className="text-3xl font-bold text-primary">{score}</p>
                  <p className="text-sm text-muted-foreground">Score</p>
                </div>
                <div className="bg-accent/10 rounded-lg p-4">
                  <p className="text-3xl font-bold text-accent">{accuracy}%</p>
                  <p className="text-sm text-muted-foreground">Accuracy</p>
                </div>
                <div className="bg-secondary/10 rounded-lg p-4">
                  <p className="text-3xl font-bold text-secondary">{formatTime(3600 - timeLeft)}</p>
                  <p className="text-sm text-muted-foreground">Time Taken</p>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-muted-foreground">
                  You got {Object.values(quizState.answers).filter((ans, idx) => ans === questions[idx]?.correctOption).length} out of {questions.length} correct
                </p>
              </div>

              <Button
                onClick={() => (window.location.href = "/dashboard")}
                className="bg-primary hover:bg-primary/90 text-primary-foreground w-full"
              >
                Back to Dashboard
              </Button>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[quizState.currentQuestion];
  const progress = ((quizState.currentQuestion + 1) / questions.length) * 100;
  const currentAnswer = quizState.answers[currentQuestion?.id];
  const isFlagged = quizState.flagged.has(currentQuestion?.id);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/5">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold text-foreground">Quiz Engine</h1>
            <div className="text-sm text-muted-foreground">
              Question {quizState.currentQuestion + 1} of {questions.length}
            </div>
          </div>
          <div className="flex items-center gap-2 text-lg font-semibold text-foreground">
            <Clock className="w-5 h-5 text-primary" />
            {formatTime(timeLeft)}
          </div>
        </div>
        <div className="container pb-4">
          <Progress value={progress} className="h-2" />
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Question Section */}
          <div className="lg:col-span-2 space-y-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={quizState.currentQuestion}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {/* Question Text */}
                <Card className="p-8 space-y-4">
                  <div className="flex items-start justify-between">
                    <h2 className="text-2xl font-semibold text-foreground flex-1">
                      {currentQuestion?.questionText}
                    </h2>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleFlagQuestion}
                      className={isFlagged ? "text-accent" : "text-muted-foreground"}
                    >
                      <Flag className="w-5 h-5" fill={isFlagged ? "currentColor" : "none"} />
                    </Button>
                  </div>

                  {currentQuestion?.questionImageUrl && (
                    <img
                      src={currentQuestion.questionImageUrl}
                      alt="Question"
                      className="max-w-full h-auto rounded-lg"
                    />
                  )}

                  <div className="flex gap-2 text-sm">
                    <span className="px-3 py-1 rounded-full bg-primary/10 text-primary">
                      +{currentQuestion?.positiveMarks} marks
                    </span>
                    <span className="px-3 py-1 rounded-full bg-destructive/10 text-destructive">
                      -{currentQuestion?.negativeMarks} mark
                    </span>
                  </div>
                </Card>

                {/* Options */}
                <div className="space-y-3">
                  {["A", "B", "C", "D"].map((option) => {
                    const optionKey = `option${option}` as keyof Question;
                    const optionText = currentQuestion?.[optionKey];
                    const isSelected = currentAnswer === option;

                    return (
                      <motion.button
                        key={option}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleSelectOption(option)}
                        className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                          isSelected
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-primary/50 bg-card"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-6 h-6 rounded-full border-2 flex items-center justify-center font-semibold ${
                              isSelected
                                ? "border-primary bg-primary text-primary-foreground"
                                : "border-border"
                            }`}
                          >
                            {option}
                          </div>
                          <span className="text-foreground">{optionText}</span>
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button
                onClick={handlePreviousQuestion}
                disabled={quizState.currentQuestion === 0}
                variant="outline"
                className="flex-1"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>
              <Button
                onClick={handleSkipQuestion}
                variant="outline"
                className="flex-1"
              >
                <SkipForward className="w-4 h-4 mr-2" />
                Skip
              </Button>
              {quizState.currentQuestion === questions.length - 1 ? (
                <Button
                  onClick={handleSubmitQuiz}
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Submit Quiz
                </Button>
              ) : (
                <Button
                  onClick={handleNextQuestion}
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </div>

          {/* Sidebar - Question Navigator */}
          <div className="space-y-4">
            <Card className="p-4 space-y-4">
              <h3 className="font-semibold text-foreground">Questions</h3>
              <div className="grid grid-cols-5 gap-2">
                {questions.map((q, idx) => {
                  const isAnswered = quizState.answers[q.id] !== undefined && quizState.answers[q.id] !== null;
                  const isCurrent = idx === quizState.currentQuestion;
                  const isFlaggedQ = quizState.flagged.has(q.id);

                  return (
                    <motion.button
                      key={q.id}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setQuizState((prev) => ({ ...prev, currentQuestion: idx }))}
                      className={`w-10 h-10 rounded-lg font-semibold text-sm transition-all ${
                        isCurrent
                          ? "bg-primary text-primary-foreground"
                          : isAnswered
                          ? "bg-accent/20 text-accent border border-accent"
                          : "bg-secondary/50 text-foreground border border-border"
                      } ${isFlaggedQ ? "ring-2 ring-accent" : ""}`}
                    >
                      {idx + 1}
                    </motion.button>
                  );
                })}
              </div>

              <div className="border-t border-border pt-4 space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Answered</span>
                  <span className="font-semibold text-foreground">
                    {Object.values(quizState.answers).filter((a) => a !== null && a !== undefined).length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Flagged</span>
                  <span className="font-semibold text-accent">{quizState.flagged.size}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Skipped</span>
                  <span className="font-semibold text-foreground">
                    {questions.length - Object.values(quizState.answers).filter((a) => a !== null && a !== undefined).length}
                  </span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
