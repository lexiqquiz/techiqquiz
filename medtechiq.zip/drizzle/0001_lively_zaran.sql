CREATE TABLE `analytics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`total_questions_attempted` int NOT NULL DEFAULT 0,
	`correct_answers` int NOT NULL DEFAULT 0,
	`incorrect_answers` int NOT NULL DEFAULT 0,
	`skipped_questions` int NOT NULL DEFAULT 0,
	`average_accuracy` int NOT NULL DEFAULT 0,
	`total_time_spent` int NOT NULL DEFAULT 0,
	`subject_wise_stats` text,
	`weak_areas` text,
	`last_updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `analytics_id` PRIMARY KEY(`id`),
	CONSTRAINT `analytics_user_id_unique` UNIQUE(`user_id`)
);
--> statement-breakpoint
CREATE TABLE `flashcards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`subject` enum('Physics','Chemistry','Biology','Mathematics') NOT NULL,
	`front` text NOT NULL,
	`back` text NOT NULL,
	`difficulty` enum('easy','medium','hard') NOT NULL DEFAULT 'medium',
	`review_count` int NOT NULL DEFAULT 0,
	`last_reviewed_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `flashcards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gamification` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`total_points` int NOT NULL DEFAULT 0,
	`streak_days` int NOT NULL DEFAULT 0,
	`last_activity_date` timestamp,
	`badges` text,
	`level` int NOT NULL DEFAULT 1,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gamification_id` PRIMARY KEY(`id`),
	CONSTRAINT `gamification_user_id_unique` UNIQUE(`user_id`)
);
--> statement-breakpoint
CREATE TABLE `mistake_notebook` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`question_id` int NOT NULL,
	`user_answer_id` int,
	`retry_count` int NOT NULL DEFAULT 0,
	`last_reviewed_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mistake_notebook_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`type` enum('study_goal','mock_test','streak','motivation','achievement') NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`is_read` int NOT NULL DEFAULT 0,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`subject` enum('Physics','Chemistry','Biology','Mathematics') NOT NULL,
	`chapter` varchar(255) NOT NULL,
	`is_pyq` int NOT NULL DEFAULT 0,
	`pyq_year` int,
	`question_text` text NOT NULL,
	`question_image_url` varchar(500),
	`option_a` text,
	`option_b` text,
	`option_c` text,
	`option_d` text,
	`option_image_urls` text,
	`correct_option` varchar(1) NOT NULL,
	`positive_marks` int NOT NULL DEFAULT 4,
	`negative_marks` int NOT NULL DEFAULT 1,
	`explanation` text,
	`difficulty` enum('easy','medium','hard') NOT NULL DEFAULT 'medium',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quiz_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`quiz_type` enum('NCERT_Chapter','Full_Mock','PYQ','Custom') NOT NULL,
	`subject` enum('Physics','Chemistry','Biology','Mathematics'),
	`total_score` int NOT NULL,
	`max_score` int NOT NULL,
	`accuracy_percentage` int,
	`time_taken_seconds` int,
	`subject_breakdown` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quiz_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`stripe_customer_id` varchar(255),
	`stripe_subscription_id` varchar(255),
	`plan` enum('free','premium','pro') NOT NULL DEFAULT 'free',
	`status` enum('active','cancelled','expired') NOT NULL DEFAULT 'active',
	`current_period_start` timestamp,
	`current_period_end` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `subscriptions_user_id_unique` UNIQUE(`user_id`)
);
--> statement-breakpoint
CREATE TABLE `user_answers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`session_id` int NOT NULL,
	`user_id` int NOT NULL,
	`question_id` int NOT NULL,
	`selected_option` varchar(1),
	`is_correct` int,
	`is_skipped` int NOT NULL DEFAULT 0,
	`time_spent_seconds` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_answers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `analytics` ADD CONSTRAINT `analytics_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `flashcards` ADD CONSTRAINT `flashcards_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `gamification` ADD CONSTRAINT `gamification_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mistake_notebook` ADD CONSTRAINT `mistake_notebook_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mistake_notebook` ADD CONSTRAINT `mistake_notebook_question_id_questions_id_fk` FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mistake_notebook` ADD CONSTRAINT `mistake_notebook_user_answer_id_user_answers_id_fk` FOREIGN KEY (`user_answer_id`) REFERENCES `user_answers`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `quiz_sessions` ADD CONSTRAINT `quiz_sessions_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `subscriptions` ADD CONSTRAINT `subscriptions_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_answers` ADD CONSTRAINT `user_answers_session_id_quiz_sessions_id_fk` FOREIGN KEY (`session_id`) REFERENCES `quiz_sessions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_answers` ADD CONSTRAINT `user_answers_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_answers` ADD CONSTRAINT `user_answers_question_id_questions_id_fk` FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE cascade ON UPDATE no action;