import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// MEDTECHIQ TABLES

// Questions table with support for NEET/JEE specific requirements
export const questions = mysqlTable("questions", {
  id: int("id").autoincrement().primaryKey(),
  subject: mysqlEnum("subject", ["Physics", "Chemistry", "Biology", "Mathematics"]).notNull(),
  chapter: varchar("chapter", { length: 255 }).notNull(),
  isPyq: int("is_pyq").default(0).notNull(),
  pyqYear: int("pyq_year"),
  questionText: text("question_text").notNull(),
  questionImageUrl: varchar("question_image_url", { length: 500 }),
  optionA: text("option_a"),
  optionB: text("option_b"),
  optionC: text("option_c"),
  optionD: text("option_d"),
  optionImageUrls: text("option_image_urls"), // JSON array
  correctOption: varchar("correct_option", { length: 1 }).notNull(),
  positiveMarks: int("positive_marks").default(4).notNull(),
  negativeMarks: int("negative_marks").default(1).notNull(),
  explanation: text("explanation"),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;

// Quiz sessions table for tracking user performance
export const quizSessions = mysqlTable("quiz_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  quizType: mysqlEnum("quiz_type", ["NCERT_Chapter", "Full_Mock", "PYQ", "Custom"]).notNull(),
  subject: mysqlEnum("subject", ["Physics", "Chemistry", "Biology", "Mathematics"]),
  totalScore: int("total_score").notNull(),
  maxScore: int("max_score").notNull(),
  accuracyPercentage: int("accuracy_percentage"),
  timeTakenSeconds: int("time_taken_seconds"),
  subjectBreakdown: text("subject_breakdown"), // JSON
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type QuizSession = typeof quizSessions.$inferSelect;
export type InsertQuizSession = typeof quizSessions.$inferInsert;

// User answers table for tracking individual question attempts
export const userAnswers = mysqlTable("user_answers", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("session_id").notNull().references(() => quizSessions.id, { onDelete: "cascade" }),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  questionId: int("question_id").notNull().references(() => questions.id, { onDelete: "cascade" }),
  selectedOption: varchar("selected_option", { length: 1 }),
  isCorrect: int("is_correct"),
  isSkipped: int("is_skipped").default(0).notNull(),
  timeSpentSeconds: int("time_spent_seconds"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type UserAnswer = typeof userAnswers.$inferSelect;
export type InsertUserAnswer = typeof userAnswers.$inferInsert;

// Flashcards table
export const flashcards = mysqlTable("flashcards", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  subject: mysqlEnum("subject", ["Physics", "Chemistry", "Biology", "Mathematics"]).notNull(),
  front: text("front").notNull(),
  back: text("back").notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium").notNull(),
  reviewCount: int("review_count").default(0).notNull(),
  lastReviewedAt: timestamp("last_reviewed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Flashcard = typeof flashcards.$inferSelect;
export type InsertFlashcard = typeof flashcards.$inferInsert;

// Gamification table
export const gamification = mysqlTable("gamification", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  totalPoints: int("total_points").default(0).notNull(),
  streakDays: int("streak_days").default(0).notNull(),
  lastActivityDate: timestamp("last_activity_date"),
  badges: text("badges"), // JSON array
  level: int("level").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Gamification = typeof gamification.$inferSelect;
export type InsertGamification = typeof gamification.$inferInsert;

// Mistake notebook table
export const mistakeNotebook = mysqlTable("mistake_notebook", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  questionId: int("question_id").notNull().references(() => questions.id, { onDelete: "cascade" }),
  userAnswerId: int("user_answer_id").references(() => userAnswers.id, { onDelete: "cascade" }),
  retryCount: int("retry_count").default(0).notNull(),
  lastReviewedAt: timestamp("last_reviewed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type MistakeNotebook = typeof mistakeNotebook.$inferSelect;
export type InsertMistakeNotebook = typeof mistakeNotebook.$inferInsert;

// Analytics table
export const analytics = mysqlTable("analytics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  totalQuestionsAttempted: int("total_questions_attempted").default(0).notNull(),
  correctAnswers: int("correct_answers").default(0).notNull(),
  incorrectAnswers: int("incorrect_answers").default(0).notNull(),
  skippedQuestions: int("skipped_questions").default(0).notNull(),
  averageAccuracy: int("average_accuracy").default(0).notNull(),
  totalTimeSpent: int("total_time_spent").default(0).notNull(),
  subjectWiseStats: text("subject_wise_stats"), // JSON
  weakAreas: text("weak_areas"), // JSON array
  lastUpdatedAt: timestamp("last_updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = typeof analytics.$inferInsert;

// Premium subscription table
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  plan: mysqlEnum("plan", ["free", "premium", "pro"]).default("free").notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "expired"]).default("active").notNull(),
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

// Notifications table
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: mysqlEnum("type", ["study_goal", "mock_test", "streak", "motivation", "achievement"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: int("is_read").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;