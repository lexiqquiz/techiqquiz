import { eq, and, desc, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, questions, quizSessions, userAnswers, flashcards, gamification, mistakeNotebook, analytics, subscriptions, notifications } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Question queries
export async function getQuestionsBySubject(subject: string, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(questions)
    .where(eq(questions.subject, subject as any))
    .limit(limit);
  return result;
}

export async function getQuestionsByChapter(subject: string, chapter: string, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(questions)
    .where(and(
      eq(questions.subject, subject as any),
      eq(questions.chapter, chapter)
    ))
    .limit(limit);
  return result;
}

export async function getQuestionById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(questions)
    .where(eq(questions.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

// Quiz session queries
export async function createQuizSession(userId: number, quizType: string, subject: string | null, totalScore: number, maxScore: number, timeTakenSeconds: number, subjectBreakdown: any) {
  const db = await getDb();
  if (!db) return null;
  
  const accuracy = Math.round((totalScore / maxScore) * 100);
  
  const result = await db.insert(quizSessions).values({
    userId,
    quizType: quizType as any,
    subject: subject as any,
    totalScore,
    maxScore,
    accuracyPercentage: accuracy,
    timeTakenSeconds,
    subjectBreakdown: JSON.stringify(subjectBreakdown),
  });
  
  return result;
}

export async function getUserQuizSessions(userId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(quizSessions)
    .where(eq(quizSessions.userId, userId))
    .orderBy(desc(quizSessions.createdAt))
    .limit(limit);
  return result;
}

// User answer queries
export async function recordUserAnswer(sessionId: number, userId: number, questionId: number, selectedOption: string | null, isCorrect: boolean, isSkipped: boolean, timeSpentSeconds: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(userAnswers).values({
    sessionId,
    userId,
    questionId,
    selectedOption: selectedOption as any,
    isCorrect: isCorrect ? 1 : 0,
    isSkipped: isSkipped ? 1 : 0,
    timeSpentSeconds,
  });
  
  return result;
}

// Flashcard queries
export async function getUserFlashcards(userId: number, subject?: string) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions = [eq(flashcards.userId, userId)];
  if (subject) {
    conditions.push(eq(flashcards.subject, subject as any));
  }
  
  const result = await db.select().from(flashcards)
    .where(and(...conditions))
    .orderBy(desc(flashcards.lastReviewedAt));
  return result;
}

export async function createFlashcard(userId: number, subject: string, front: string, back: string, difficulty: string = "medium") {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(flashcards).values({
    userId,
    subject: subject as any,
    front,
    back,
    difficulty: difficulty as any,
  });
  
  return result;
}

// Gamification queries
export async function getOrCreateGamification(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const existing = await db.select().from(gamification)
    .where(eq(gamification.userId, userId))
    .limit(1);
  
  if (existing.length > 0) {
    return existing[0];
  }
  
  await db.insert(gamification).values({
    userId,
    totalPoints: 0,
    streakDays: 0,
  });
  
  const result = await db.select().from(gamification)
    .where(eq(gamification.userId, userId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export async function updateGamification(userId: number, points: number, streakDays: number, badges?: any) {
  const db = await getDb();
  if (!db) return null;
  
  const updateData: any = {
    totalPoints: points,
    streakDays,
    lastActivityDate: new Date(),
  };
  
  if (badges) {
    updateData.badges = JSON.stringify(badges);
  }
  
  await db.update(gamification)
    .set(updateData)
    .where(eq(gamification.userId, userId));
  
  const result = await db.select().from(gamification)
    .where(eq(gamification.userId, userId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

// Mistake notebook queries
export async function addToMistakeNotebook(userId: number, questionId: number, userAnswerId?: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(mistakeNotebook).values({
    userId,
    questionId,
    userAnswerId: userAnswerId || null,
  });
  
  return result;
}

export async function getUserMistakes(userId: number, limit: number = 20) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(mistakeNotebook)
    .where(eq(mistakeNotebook.userId, userId))
    .orderBy(desc(mistakeNotebook.createdAt))
    .limit(limit);
  return result;
}

// Analytics queries
export async function getOrCreateAnalytics(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const existing = await db.select().from(analytics)
    .where(eq(analytics.userId, userId))
    .limit(1);
  
  if (existing.length > 0) {
    return existing[0];
  }
  
  await db.insert(analytics).values({
    userId,
    totalQuestionsAttempted: 0,
    correctAnswers: 0,
    incorrectAnswers: 0,
    skippedQuestions: 0,
    averageAccuracy: 0,
    totalTimeSpent: 0,
  });
  
  const result = await db.select().from(analytics)
    .where(eq(analytics.userId, userId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export async function updateAnalytics(userId: number, stats: any) {
  const db = await getDb();
  if (!db) return null;
  
  const updateData: any = {
    totalQuestionsAttempted: stats.totalQuestionsAttempted || 0,
    correctAnswers: stats.correctAnswers || 0,
    incorrectAnswers: stats.incorrectAnswers || 0,
    skippedQuestions: stats.skippedQuestions || 0,
    averageAccuracy: stats.averageAccuracy || 0,
    totalTimeSpent: stats.totalTimeSpent || 0,
  };
  
  if (stats.subjectWiseStats) {
    updateData.subjectWiseStats = JSON.stringify(stats.subjectWiseStats);
  }
  
  if (stats.weakAreas) {
    updateData.weakAreas = JSON.stringify(stats.weakAreas);
  }
  
  await db.update(analytics)
    .set(updateData)
    .where(eq(analytics.userId, userId));
  
  const result = await db.select().from(analytics)
    .where(eq(analytics.userId, userId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

// Subscription queries
export async function getOrCreateSubscription(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const existing = await db.select().from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .limit(1);
  
  if (existing.length > 0) {
    return existing[0];
  }
  
  await db.insert(subscriptions).values({
    userId,
    plan: "free",
    status: "active",
  });
  
  const result = await db.select().from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

// Notification queries
export async function createNotification(userId: number, type: string, title: string, message: string) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(notifications).values({
    userId,
    type: type as any,
    title,
    message,
    isRead: 0,
  });
  
  return result;
}

export async function getUserNotifications(userId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
  return result;
}
