import { describe, it, expect, beforeEach, vi } from "vitest";
import * as db from "./db";

describe("Database Features", () => {
  describe("Question Queries", () => {
    it("should fetch questions by subject", async () => {
      const questions = await db.getQuestionsBySubject("Physics", 5);
      expect(Array.isArray(questions)).toBe(true);
    });

    it("should fetch questions by chapter", async () => {
      const questions = await db.getQuestionsByChapter("Physics", "Mechanics", 5);
      expect(Array.isArray(questions)).toBe(true);
    });

    it("should fetch question by ID", async () => {
      const question = await db.getQuestionById(1);
      if (question) {
        expect(question).toHaveProperty("id");
        expect(question).toHaveProperty("questionText");
        expect(question).toHaveProperty("correctOption");
      }
    });
  });

  describe("Gamification", () => {
    it("should create or get gamification record", async () => {
      const gamification = await db.getOrCreateGamification(1);
      expect(gamification).toBeDefined();
      if (gamification) {
        expect(gamification).toHaveProperty("userId");
        expect(gamification).toHaveProperty("totalPoints");
        expect(gamification).toHaveProperty("streakDays");
      }
    });

    it("should update gamification stats", async () => {
      const updated = await db.updateGamification(1, 100, 5, ["badge1"]);
      expect(updated).toBeDefined();
      if (updated) {
        expect(updated.totalPoints).toBe(100);
        expect(updated.streakDays).toBe(5);
      }
    });
  });

  describe("Analytics", () => {
    it("should create or get analytics record", async () => {
      const analytics = await db.getOrCreateAnalytics(1);
      expect(analytics).toBeDefined();
      if (analytics) {
        expect(analytics).toHaveProperty("userId");
        expect(analytics).toHaveProperty("totalQuestionsAttempted");
        expect(analytics).toHaveProperty("correctAnswers");
      }
    });

    it("should update analytics stats", async () => {
      const stats = {
        totalQuestionsAttempted: 50,
        correctAnswers: 45,
        incorrectAnswers: 5,
        skippedQuestions: 0,
        averageAccuracy: 90,
        totalTimeSpent: 3600,
      };
      const updated = await db.updateAnalytics(1, stats);
      expect(updated).toBeDefined();
    });
  });

  describe("Flashcards", () => {
    it("should create a flashcard", async () => {
      const result = await db.createFlashcard(
        1,
        "Physics",
        "What is velocity?",
        "Rate of change of displacement",
        "medium"
      );
      expect(result).toBeDefined();
    });

    it("should get user flashcards", async () => {
      const flashcards = await db.getUserFlashcards(1);
      expect(Array.isArray(flashcards)).toBe(true);
    });

    it("should get flashcards by subject", async () => {
      const flashcards = await db.getUserFlashcards(1, "Physics");
      expect(Array.isArray(flashcards)).toBe(true);
    });
  });

  describe("Mistake Notebook", () => {
    it("should add question to mistake notebook", async () => {
      const result = await db.addToMistakeNotebook(1, 1);
      expect(result).toBeDefined();
    });

    it("should get user mistakes", async () => {
      const mistakes = await db.getUserMistakes(1);
      expect(Array.isArray(mistakes)).toBe(true);
    });
  });

  describe("Notifications", () => {
    it("should create a notification", async () => {
      const result = await db.createNotification(
        1,
        "study_goal",
        "Daily Goal Reminder",
        "Complete 10 questions today"
      );
      expect(result).toBeDefined();
    });

    it("should get user notifications", async () => {
      const notifications = await db.getUserNotifications(1);
      expect(Array.isArray(notifications)).toBe(true);
    });
  });

  describe("Subscriptions", () => {
    it("should create or get subscription", async () => {
      const subscription = await db.getOrCreateSubscription(1);
      expect(subscription).toBeDefined();
      if (subscription) {
        expect(subscription).toHaveProperty("userId");
        expect(subscription).toHaveProperty("plan");
        expect(subscription.plan).toBe("free");
      }
    });
  });

  describe("Quiz Sessions", () => {
    it("should create quiz session", async () => {
      const result = await db.createQuizSession(
        1,
        "Full_Mock",
        "Physics",
        80,
        100,
        1800,
        { Physics: { correct: 20, incorrect: 0 } }
      );
      expect(result).toBeDefined();
    });

    it("should get user quiz sessions", async () => {
      const sessions = await db.getUserQuizSessions(1);
      expect(Array.isArray(sessions)).toBe(true);
    });
  });

  describe("User Answers", () => {
    it("should record user answer", async () => {
      const result = await db.recordUserAnswer(1, 1, 1, "A", true, false, 30);
      expect(result).toBeDefined();
    });
  });
});

describe("Quiz Engine Logic", () => {
  it("should calculate score with positive marks", () => {
    const questions = [
      { id: 1, correctOption: "A", positiveMarks: 4, negativeMarks: 1 },
      { id: 2, correctOption: "B", positiveMarks: 4, negativeMarks: 1 },
    ];
    const answers: Record<number, string | null> = {
      1: "A",
      2: "B",
    };

    let score = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctOption) {
        score += q.positiveMarks;
      }
    });

    expect(score).toBe(8);
  });

  it("should deduct negative marks for wrong answers", () => {
    const questions = [
      { id: 1, correctOption: "A", positiveMarks: 4, negativeMarks: 1 },
      { id: 2, correctOption: "B", positiveMarks: 4, negativeMarks: 1 },
    ];
    const answers: Record<number, string | null> = {
      1: "C",
      2: "B",
    };

    let score = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctOption) {
        score += q.positiveMarks;
      } else if (answers[q.id] !== null && answers[q.id] !== undefined) {
        score -= q.negativeMarks;
      }
    });

    expect(score).toBe(3);
  });

  it("should not deduct marks for skipped questions", () => {
    const questions = [
      { id: 1, correctOption: "A", positiveMarks: 4, negativeMarks: 1 },
      { id: 2, correctOption: "B", positiveMarks: 4, negativeMarks: 1 },
    ];
    const answers: Record<number, string | null> = {
      1: null,
      2: "B",
    };

    let score = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctOption) {
        score += q.positiveMarks;
      } else if (answers[q.id] !== null && answers[q.id] !== undefined) {
        score -= q.negativeMarks;
      }
    });

    expect(score).toBe(4);
  });

  it("should calculate accuracy percentage", () => {
    const totalQuestions = 10;
    const correctAnswers = 8;
    const accuracy = Math.round((correctAnswers / totalQuestions) * 100);
    expect(accuracy).toBe(80);
  });

  it("should format time correctly", () => {
    const formatTime = (seconds: number) => {
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const secs = seconds % 60;
      return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
    };

    expect(formatTime(3661)).toBe("01:01:01");
    expect(formatTime(120)).toBe("00:02:00");
    expect(formatTime(45)).toBe("00:00:45");
  });
});

describe("Gamification Logic", () => {
  it("should calculate level based on points", () => {
    const calculateLevel = (points: number) => {
      return Math.floor(points / 500) + 1;
    };

    expect(calculateLevel(0)).toBe(1);
    expect(calculateLevel(500)).toBe(2);
    expect(calculateLevel(2000)).toBe(5);
  });

  it("should award badges based on achievements", () => {
    const awardBadges = (stats: { streakDays: number; accuracy: number; questionsAttempted: number }) => {
      const badges = [];
      if (stats.streakDays >= 7) badges.push("Streak Master");
      if (stats.accuracy >= 90) badges.push("Perfect Scorer");
      if (stats.questionsAttempted >= 100) badges.push("Question Warrior");
      return badges;
    };

    expect(awardBadges({ streakDays: 7, accuracy: 85, questionsAttempted: 50 })).toContain("Streak Master");
    expect(awardBadges({ streakDays: 5, accuracy: 95, questionsAttempted: 150 })).toContain("Perfect Scorer");
    expect(awardBadges({ streakDays: 10, accuracy: 92, questionsAttempted: 200 })).toHaveLength(3);
  });
});
