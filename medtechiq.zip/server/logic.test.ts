import { describe, it, expect } from "vitest";

describe("Quiz Engine Logic", () => {
  it("should calculate score with positive marks for correct answers", () => {
    const questions = [
      { id: 1, correctOption: "A", positiveMarks: 4, negativeMarks: 1 },
      { id: 2, correctOption: "B", positiveMarks: 4, negativeMarks: 1 },
    ];
    const answers: Record<number, string | null> = {
      1: "A",
      2: "B",
    };

    let score = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctOption) {
        score += q.positiveMarks;
      }
    });

    expect(score).toBe(8);
  });

  it("should deduct negative marks for wrong answers", () => {
    const questions = [
      { id: 1, correctOption: "A", positiveMarks: 4, negativeMarks: 1 },
      { id: 2, correctOption: "B", positiveMarks: 4, negativeMarks: 1 },
    ];
    const answers: Record<number, string | null> = {
      1: "C",
      2: "B",
    };

    let score = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctOption) {
        score += q.positiveMarks;
      } else if (answers[q.id] !== null && answers[q.id] !== undefined) {
        score -= q.negativeMarks;
      }
    });

    expect(score).toBe(3);
  });

  it("should not deduct marks for skipped questions", () => {
    const questions = [
      { id: 1, correctOption: "A", positiveMarks: 4, negativeMarks: 1 },
      { id: 2, correctOption: "B", positiveMarks: 4, negativeMarks: 1 },
    ];
    const answers: Record<number, string | null> = {
      1: null,
      2: "B",
    };

    let score = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctOption) {
        score += q.positiveMarks;
      } else if (answers[q.id] !== null && answers[q.id] !== undefined) {
        score -= q.negativeMarks;
      }
    });

    expect(score).toBe(4);
  });

  it("should handle mixed correct, incorrect, and skipped answers", () => {
    const questions = [
      { id: 1, correctOption: "A", positiveMarks: 4, negativeMarks: 1 },
      { id: 2, correctOption: "B", positiveMarks: 4, negativeMarks: 1 },
      { id: 3, correctOption: "C", positiveMarks: 4, negativeMarks: 1 },
      { id: 4, correctOption: "D", positiveMarks: 4, negativeMarks: 1 },
    ];
    const answers: Record<number, string | null> = {
      1: "A", // correct
      2: "C", // incorrect
      3: null, // skipped
      4: "D", // correct
    };

    let score = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctOption) {
        score += q.positiveMarks;
      } else if (answers[q.id] !== null && answers[q.id] !== undefined) {
        score -= q.negativeMarks;
      }
    });

    expect(score).toBe(7); // 4 + 4 - 1 = 7
  });

  it("should calculate accuracy percentage", () => {
    const calculateAccuracy = (correct: number, total: number) => {
      return Math.round((correct / total) * 100);
    };

    expect(calculateAccuracy(8, 10)).toBe(80);
    expect(calculateAccuracy(9, 10)).toBe(90);
    expect(calculateAccuracy(10, 10)).toBe(100);
    expect(calculateAccuracy(0, 10)).toBe(0);
  });

  it("should format time correctly", () => {
    const formatTime = (seconds: number) => {
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const secs = seconds % 60;
      return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
    };

    expect(formatTime(3661)).toBe("01:01:01");
    expect(formatTime(120)).toBe("00:02:00");
    expect(formatTime(45)).toBe("00:00:45");
    expect(formatTime(0)).toBe("00:00:00");
    expect(formatTime(3600)).toBe("01:00:00");
  });

  it("should track time spent per question", () => {
    const timeSpent: Record<number, number> = {
      1: 30,
      2: 45,
      3: 20,
    };

    const totalTime = Object.values(timeSpent).reduce((sum, time) => sum + time, 0);
    expect(totalTime).toBe(95);

    const avgTime = Math.round(totalTime / Object.keys(timeSpent).length);
    expect(avgTime).toBe(32);
  });

  it("should identify questions that took too long", () => {
    const timeSpent: Record<number, number> = {
      1: 30,
      2: 150, // > 2 minutes
      3: 20,
      4: 180, // > 2 minutes
    };

    const slowQuestions = Object.entries(timeSpent)
      .filter(([_, time]) => time > 120)
      .map(([id]) => parseInt(id));

    expect(slowQuestions).toEqual([2, 4]);
  });
});

describe("Gamification Logic", () => {
  it("should calculate level based on points", () => {
    const calculateLevel = (points: number) => {
      return Math.floor(points / 500) + 1;
    };

    expect(calculateLevel(0)).toBe(1);
    expect(calculateLevel(500)).toBe(2);
    expect(calculateLevel(999)).toBe(2);
    expect(calculateLevel(1000)).toBe(3);
    expect(calculateLevel(2000)).toBe(5);
  });

  it("should award badges based on achievements", () => {
    const awardBadges = (stats: {
      streakDays: number;
      accuracy: number;
      questionsAttempted: number;
    }) => {
      const badges = [];
      if (stats.streakDays >= 7) badges.push("Streak Master");
      if (stats.accuracy >= 90) badges.push("Perfect Scorer");
      if (stats.questionsAttempted >= 100) badges.push("Question Warrior");
      return badges;
    };

    expect(awardBadges({ streakDays: 7, accuracy: 85, questionsAttempted: 50 })).toContain(
      "Streak Master"
    );
    expect(awardBadges({ streakDays: 5, accuracy: 95, questionsAttempted: 150 })).toContain(
      "Perfect Scorer"
    );
    expect(awardBadges({ streakDays: 10, accuracy: 92, questionsAttempted: 200 })).toHaveLength(3);
    expect(awardBadges({ streakDays: 3, accuracy: 80, questionsAttempted: 50 })).toHaveLength(0);
  });

  it("should calculate streak continuation", () => {
    const updateStreak = (lastActivityDate: Date | null, currentDate: Date) => {
      if (!lastActivityDate) return 1;

      const daysDiff = Math.floor(
        (currentDate.getTime() - lastActivityDate.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (daysDiff === 0) return null; // Already studied today
      if (daysDiff === 1) return true; // Continue streak
      return false; // Streak broken
    };

    const today = new Date();
    const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
    const twoDaysAgo = new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000);

    expect(updateStreak(null, today)).toBe(1);
    expect(updateStreak(yesterday, today)).toBe(true);
    expect(updateStreak(twoDaysAgo, today)).toBe(false);
    expect(updateStreak(today, today)).toBe(null);
  });

  it("should calculate points earned from quiz", () => {
    const calculatePoints = (
      correctAnswers: number,
      totalQuestions: number,
      timeBonus: boolean
    ) => {
      const basePoints = correctAnswers * 10;
      const accuracyBonus = Math.round((correctAnswers / totalQuestions) * 50);
      const speedBonus = timeBonus ? 25 : 0;
      return basePoints + accuracyBonus + speedBonus;
    };

    expect(calculatePoints(8, 10, true)).toBe(80 + 40 + 25); // 145
    expect(calculatePoints(8, 10, false)).toBe(80 + 40); // 120
    expect(calculatePoints(10, 10, true)).toBe(100 + 50 + 25); // 175
  });
});

describe("Analytics Logic", () => {
  it("should identify weak areas based on accuracy", () => {
    const subjectStats = {
      Physics: { correct: 15, total: 20, accuracy: 75 },
      Chemistry: { correct: 18, total: 20, accuracy: 90 },
      Biology: { correct: 12, total: 20, accuracy: 60 },
      Mathematics: { correct: 17, total: 20, accuracy: 85 },
    };

    const weakAreas = Object.entries(subjectStats)
      .filter(([_, stats]) => stats.accuracy < 75)
      .map(([subject]) => subject);

    expect(weakAreas).toContain("Biology");
    expect(weakAreas).not.toContain("Chemistry");
  });

  it("should calculate average accuracy", () => {
    const sessions = [
      { accuracy: 80 },
      { accuracy: 85 },
      { accuracy: 90 },
      { accuracy: 75 },
    ];

    const avgAccuracy = Math.round(
      sessions.reduce((sum, s) => sum + s.accuracy, 0) / sessions.length
    );

    expect(avgAccuracy).toBe(83);
  });

  it("should calculate total time spent", () => {
    const sessions = [
      { timeTakenSeconds: 1800 },
      { timeTakenSeconds: 2400 },
      { timeTakenSeconds: 1200 },
    ];

    const totalTime = sessions.reduce((sum, s) => sum + s.timeTakenSeconds, 0);
    const totalMinutes = Math.round(totalTime / 60);

    expect(totalTime).toBe(5400);
    expect(totalMinutes).toBe(90);
  });

  it("should rank subjects by performance", () => {
    const subjectStats = [
      { subject: "Physics", accuracy: 75 },
      { subject: "Chemistry", accuracy: 90 },
      { subject: "Biology", accuracy: 60 },
      { subject: "Mathematics", accuracy: 85 },
    ];

    const ranked = subjectStats.sort((a, b) => b.accuracy - a.accuracy);

    expect(ranked[0].subject).toBe("Chemistry");
    expect(ranked[1].subject).toBe("Mathematics");
    expect(ranked[3].subject).toBe("Biology");
  });
});

describe("Flashcard Logic", () => {
  it("should determine review priority based on review count", () => {
    const flashcards = [
      { id: 1, reviewCount: 5, difficulty: "easy" },
      { id: 2, reviewCount: 1, difficulty: "hard" },
      { id: 3, reviewCount: 3, difficulty: "medium" },
    ];

    const prioritized = flashcards.sort((a, b) => a.reviewCount - b.reviewCount);

    expect(prioritized[0].id).toBe(2);
    expect(prioritized[1].id).toBe(3);
    expect(prioritized[2].id).toBe(1);
  });

  it("should filter flashcards by subject", () => {
    const flashcards = [
      { id: 1, subject: "Physics", front: "Q1" },
      { id: 2, subject: "Chemistry", front: "Q2" },
      { id: 3, subject: "Physics", front: "Q3" },
    ];

    const physicsCards = flashcards.filter((card) => card.subject === "Physics");

    expect(physicsCards).toHaveLength(2);
    expect(physicsCards[0].id).toBe(1);
    expect(physicsCards[1].id).toBe(3);
  });
});
